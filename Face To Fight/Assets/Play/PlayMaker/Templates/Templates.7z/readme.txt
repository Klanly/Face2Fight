This is the default folder for save FSM Templates.
However, you can save Templates anywhere in your Assets Folder.
In general it's a good idea to make custom folders for your own templates.